#!/usr/bin/env python3
"""
LLM Router — bundled skill script.
Reads API keys from ~/.llm-router.env, routes to the best model, returns answer.

Usage:
    python route.py "your question"
    python route.py "your question" --llm claude|gpt4|gemini|perplexity
"""

import sys
import os
import json
import argparse
from pathlib import Path

# ── Load API keys from ~/.llm-router.env ──────────────────────────────────────
env_file = Path.home() / ".llm-router.env"
if env_file.exists():
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, _, val = line.partition("=")
            os.environ.setdefault(key.strip(), val.strip())

ANTHROPIC_KEY  = os.environ.get("ANTHROPIC_API_KEY", "")
OPENAI_KEY     = os.environ.get("OPENAI_API_KEY", "")
GOOGLE_KEY     = os.environ.get("GOOGLE_API_KEY", "")
PERPLEXITY_KEY = os.environ.get("PERPLEXITY_API_KEY", "")

# ── Routing prompt ─────────────────────────────────────────────────────────────
ROUTING_PROMPT = """You are an expert AI model router. Choose the best model for this question.

Model strengths:
- perplexity: Current events, breaking news, real-time web data, recent prices, sports scores, live info, "what happened recently", questions needing citations
- gemini: Image/video analysis, very long documents (100k+ tokens), Google Workspace tasks
- gpt4: Creative writing, fiction, storytelling, poetry, humor, casual conversation, pop culture
- claude: Code, debugging, complex reasoning, document analysis, research synthesis, technical work, math, logic (default)

Respond ONLY with valid JSON — no markdown, no preamble:
{{"llm": "perplexity|gemini|gpt4|claude", "reason": "one short sentence"}}

Question: {question}"""


def route(question: str) -> tuple[str, str]:
    """Ask Claude Haiku which LLM to use. Returns (llm_name, reason)."""
    if not ANTHROPIC_KEY:
        return "claude", "No Anthropic key configured — using Claude directly"

    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_KEY)
    msg = client.messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=120,
        messages=[{"role": "user", "content": ROUTING_PROMPT.format(question=question)}],
    )
    raw = msg.content[0].text.strip()
    # Strip markdown fences if present
    if "```" in raw:
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    result = json.loads(raw.strip())
    llm = result.get("llm", "claude")
    if llm not in ("claude", "gpt4", "gemini", "perplexity"):
        llm = "claude"
    return llm, result.get("reason", "Best overall fit")


# ── LLM callers ───────────────────────────────────────────────────────────────

def call_claude(q: str) -> str:
    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_KEY)
    r = client.messages.create(
        model="claude-opus-4-5-20251101",
        max_tokens=4096,
        messages=[{"role": "user", "content": q}],
    )
    return r.content[0].text


def call_gpt4(q: str) -> str:
    import openai
    client = openai.OpenAI(api_key=OPENAI_KEY)
    r = client.chat.completions.create(
        model="gpt-4o",
        max_tokens=4096,
        messages=[{"role": "user", "content": q}],
    )
    return r.choices[0].message.content


def call_gemini(q: str) -> str:
    import google.generativeai as genai
    genai.configure(api_key=GOOGLE_KEY)
    model = genai.GenerativeModel("gemini-1.5-pro")
    return model.generate_content(q).text


def call_perplexity(q: str) -> str:
    import requests
    r = requests.post(
        "https://api.perplexity.ai/chat/completions",
        json={
            "model": "llama-3.1-sonar-large-128k-online",
            "messages": [{"role": "user", "content": q}],
            "max_tokens": 4096,
        },
        headers={
            "Authorization": f"Bearer {PERPLEXITY_KEY}",
            "Content-Type": "application/json",
        },
        timeout=60,
    )
    r.raise_for_status()
    data = r.json()
    answer = data["choices"][0]["message"]["content"]
    citations = data.get("citations", [])
    if citations:
        answer += "\n\n**Sources:**\n" + "\n".join(
            f"[{i+1}] {url}" for i, url in enumerate(citations)
        )
    return answer


CALLERS = {
    "claude": call_claude,
    "gpt4": call_gpt4,
    "gemini": call_gemini,
    "perplexity": call_perplexity,
}

DISPLAY_NAMES = {
    "claude": "Claude (Anthropic)",
    "gpt4": "GPT-4o (OpenAI)",
    "gemini": "Gemini 1.5 Pro (Google)",
    "perplexity": "Perplexity (Online)",
}


# ── Key validation ─────────────────────────────────────────────────────────────

def check_key(llm: str) -> str | None:
    """Return an error string if the required API key is missing."""
    needed = {
        "claude": ("ANTHROPIC_API_KEY", ANTHROPIC_KEY),
        "gpt4": ("OPENAI_API_KEY", OPENAI_KEY),
        "gemini": ("GOOGLE_API_KEY", GOOGLE_KEY),
        "perplexity": ("PERPLEXITY_API_KEY", PERPLEXITY_KEY),
    }
    var, val = needed[llm]
    if not val:
        return f"Missing {var} in ~/.llm-router.env"
    return None


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="LLM Router")
    parser.add_argument("question", help="Question or task to route")
    parser.add_argument(
        "--llm",
        choices=["claude", "gpt4", "gemini", "perplexity"],
        help="Force a specific model (skips routing)",
    )
    args = parser.parse_args()

    question = args.question

    # Route or use override
    if args.llm:
        chosen, reason = args.llm, "Manually specified by user"
    else:
        print("🔀 Routing...", file=sys.stderr)
        try:
            chosen, reason = route(question)
        except Exception as e:
            print(f"⚠️  Routing failed ({e}), defaulting to Claude", file=sys.stderr)
            chosen, reason = "claude", f"Fallback after routing error: {e}"

    # Check the required key exists
    key_error = check_key(chosen)
    if key_error:
        print(f"❌ {key_error}", file=sys.stderr)
        sys.exit(1)

    # Log routing decision to stderr (Claude reads this for context)
    print(f"", file=sys.stderr)
    print(f"{'─'*55}", file=sys.stderr)
    print(f"🤖 Model: {DISPLAY_NAMES[chosen]}", file=sys.stderr)
    print(f"   Why:   {reason}", file=sys.stderr)
    print(f"{'─'*55}", file=sys.stderr)
    print(f"", file=sys.stderr)

    # Call the LLM and print answer to stdout
    try:
        answer = CALLERS[chosen](question)
        print(answer)
    except Exception as e:
        print(f"❌ {DISPLAY_NAMES[chosen]} failed: {e}", file=sys.stderr)
        # Try Claude as fallback
        if chosen != "claude":
            print("↩️  Falling back to Claude...", file=sys.stderr)
            try:
                answer = call_claude(question)
                print(answer)
            except Exception as e2:
                print(f"❌ Claude also failed: {e2}", file=sys.stderr)
                sys.exit(1)
        else:
            sys.exit(1)


if __name__ == "__main__":
    main()
