---
name: llm-router
description: >
  Routes any question or task to the best AI model — Claude, GPT-4o, Gemini,
  or Perplexity — based on what's being asked. Uses Claude Haiku as a fast
  meta-router to decide, then calls the winning LLM and returns the answer.

  Use this skill whenever the user wants to route a question to the best AI,
  asks "which AI should answer this", says "use the LLM router", or just asks
  a question and you want to give it to the optimal model rather than answering
  as Claude. Also invoke this when the user says things like "ask the best AI",
  "let the router decide", or "try Perplexity / GPT / Gemini on this". When in
  doubt about which model to use for a complex or specialized task, trigger this
  skill automatically — it costs almost nothing to route and often gets a much
  better result.
---

# LLM Router Skill

## What This Skill Does

Routes the user's question to the best AI — Claude, GPT-4o, Gemini, or
Perplexity — by asking Claude Haiku to make the call, then returns that
model's response. The user sees which model was chosen and why.

## Routing Logic

| Model | Best for |
|-------|----------|
| **Perplexity** | Current events, live web data, news, prices, sports, citations, "what happened recently" |
| **Gemini** | Images/video, very long documents, Google Workspace tasks |
| **GPT-4o** | Creative writing, fiction, poetry, casual conversation, humor |
| **Claude** | Code, reasoning, analysis, research synthesis, technical tasks (default) |

## One-Time Setup (first use only)

Before routing works, the user needs API keys in a config file. Check once:

```bash
cat ~/.llm-router.env 2>/dev/null | head -1
```

If the file is missing or empty, guide them through setup:

1. Create the config file:
   ```bash
   cat > ~/.llm-router.env << 'EOF'
   ANTHROPIC_API_KEY=sk-ant-...
   OPENAI_API_KEY=sk-proj-...
   GOOGLE_API_KEY=AI...
   PERPLEXITY_API_KEY=pplx-...
   EOF
   ```
2. Have them replace the placeholder values with their real keys:
   - Anthropic: https://console.anthropic.com/settings/keys
   - OpenAI: https://platform.openai.com/api-keys
   - Google: https://aistudio.google.com/app/apikey
   - Perplexity: https://www.perplexity.ai/settings/api

## How to Run the Router

The routing script is bundled with this skill. When this skill loads, its
base directory is shown at the top of the system message (e.g.,
"Base directory for this skill: /path/to/llm-router"). Use that path:

```bash
# Install deps if needed (one-time, fast)
pip install anthropic openai google-generativeai requests python-dotenv --break-system-packages -q 2>/dev/null || true

# Run the router (replace BASE_DIR with the actual skill base path)
python BASE_DIR/scripts/route.py "QUESTION_HERE"
```

To force a specific model:
```bash
python BASE_DIR/scripts/route.py "QUESTION_HERE" --llm claude
python BASE_DIR/scripts/route.py "QUESTION_HERE" --llm gpt4
python BASE_DIR/scripts/route.py "QUESTION_HERE" --llm gemini
python BASE_DIR/scripts/route.py "QUESTION_HERE" --llm perplexity
```

The script prints:
- **stderr**: which model was chosen and why (for your awareness)
- **stdout**: the model's answer (show this to the user)

## Presenting the Result

Format your response like this — keep it clean and clear:

```
🤖 **[Model Name]**
*Why: [routing reason in one sentence]*

[answer]
```

If the answer includes sources (Perplexity always does), present them as a
"Sources" section at the bottom.

## If Something Goes Wrong

- **Missing API key**: Tell the user which key is missing and link them to
  where to get it (see setup section above)
- **Script not found**: The skill may not be installed yet — tell the user
  to install it via Cowork settings (the .skill file)
- **LLM API error**: Fall back to answering as Claude directly, and note
  that the routing was unavailable
- **Import error**: Run the pip install command above, then retry

## Manual Override

If the user says "use GPT", "ask Perplexity", "try Gemini" — honor that
directly with the `--llm` flag rather than routing automatically. The user
knows what they want.
